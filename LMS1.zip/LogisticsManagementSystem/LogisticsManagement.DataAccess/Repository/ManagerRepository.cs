﻿using LogisticsManagement.DataAccess.Models;
using LogisticsManagement.DataAccess.Repository.IRepository;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogisticsManagement.DataAccess.Repository
{
    public class ManagerRepository : IManagerRepository
    {
        private readonly LogisticsManagementContext _db;
        public ManagerRepository(LogisticsManagementContext db)
        {
            _db = db;
        }
        public async Task<List<InventoryCategory>?> GetInventoryCategories()
        {
            try
            {
                return await _db.InventoryCategories.ToListAsync();
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
                return null;
            }
        }

        public async Task<InventoryCategory?> GetInventoryCategory(int id)
        {
            try
            {
                return await _db.InventoryCategories.FirstOrDefaultAsync(inv => inv.Id == id);
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
                return null;
            }
        }

        public async Task<int> AddInventoryCategory(InventoryCategory category)
        {
            throw new NotImplementedException();
        }

        public async Task<int> RemoveInventoryCategory(int id)
        {
            throw new NotImplementedException();
        }
    }
}
