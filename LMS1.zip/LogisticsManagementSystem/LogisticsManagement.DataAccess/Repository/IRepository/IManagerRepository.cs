﻿using LogisticsManagement.DataAccess.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogisticsManagement.DataAccess.Repository.IRepository
{
    public interface IManagerRepository
    {
        // // // Manage Inventory Category // // //
        public Task<List<InventoryCategory>> GetInventoryCategories();
        public Task<InventoryCategory?> GetInventoryCategory(int id);
        public Task<int> AddInventoryCategory(InventoryCategory category);
        public Task<int> RemoveInventoryCategory(int id);



        // // // Manage Inventory // // // 
    }
}
